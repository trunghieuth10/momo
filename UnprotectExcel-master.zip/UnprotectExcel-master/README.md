# Unprotect Excel

Some excel files you have maybe protected against modification with a password.

Unfortunately, you don't have it.

Then, you should try this script to unprotect the excel worksheet.

It only takes you a second to unprotect your files.

You may need to modify the script as the script only unprotect the first worksheet.

To run the script

```

Powershell -File "./unprotect_excel.ps1" -EXCEL "./your_excel_file.xlsx"

```

Only work for excel files with these extensions: `.xlxs, .xlsm`












